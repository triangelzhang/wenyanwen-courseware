#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""文言文课件构建器：lesson.json -> 单文件 HTML 课件。

用法：
    python3 build.py lesson.json -o 输出.html [--template 模板路径] [--strict]

lesson.json 结构见 references/lesson-schema.md。
原文中重点字用行内标记标注：[[字词|类型|解释|例句(可选)]]
类型：tj=通假字 / gj=古今异义 / hy=词类活用 / zd=重点字词
"""

import argparse
import json
import os
import re
import sys

MARK_RE = re.compile(r"\[\[(.+?)\]\]")
TYPE_LABEL = {"tj": "通假字", "gj": "古今异义", "hy": "词类活用", "zd": "重点字词"}
CN_NUM = "一二三四五六七八九十"


def cn_index(n):
    """1 -> 一, 11 -> 十一, 21 -> 二十一"""
    if n <= 10:
        return CN_NUM[n - 1]
    if n < 20:
        return "十" + CN_NUM[n - 11]
    tens, ones = divmod(n, 10)
    return CN_NUM[tens - 1] + "十" + (CN_NUM[ones - 1] if ones else "")


def esc(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def render_orig(text, idx, problems, warns):
    """把带 [[ ]] 标记的原文转成 HTML，并返回 (html, 标记列表)。"""
    if text.count("[[") != text.count("]]"):
        problems.append("第%d段：重点字标记 [[ ]] 不配对" % idx)
    out, notes, pos = [], [], 0
    seen = set()
    for m in MARK_RE.finditer(text):
        out.append(esc(text[pos:m.start()]))
        parts = [p.strip() for p in m.group(1).split("|")]
        if len(parts) < 3:
            problems.append("第%d段：标记 %r 字段不足（至少 字词|类型|解释）" % (idx, m.group(1)))
            out.append(esc(m.group(1)))
            pos = m.end()
            continue
        word, typ, exp = parts[0], parts[1].lower(), parts[2]
        eg = parts[3] if len(parts) > 3 else ""
        if typ not in TYPE_LABEL:
            problems.append("第%d段：标记 %r 的类型 %r 非法（应为 tj/gj/hy/zd）" % (idx, word, typ))
            typ = "zd"
        if not word:
            problems.append("第%d段：存在空的重点字标记")
        if len(word) > 6:
            warns.append("第%d段：重点字 %r 过长，建议只标单字或双音节词" % (idx, word))
        out.append('<span class="hl %s" data-tip="%s">%s</span>'
                   % (typ, esc(exp).replace('"', "&quot;"), esc(word)))
        if word not in seen:
            seen.add(word)
            notes.append({"zi": word, "type": typ, "exp": exp, "eg": eg})
        pos = m.end()
    out.append(esc(text[pos:]))
    leftover = MARK_RE.sub("", text)
    if "[[" in leftover or "]]" in leftover:
        problems.append("第%d段：存在无法解析的标记（检查括号是否为全角或嵌套）" % idx)
    return "".join(out), notes


def render_cards(notes, idx, warns):
    if not notes:
        warns.append("第%d段：没有重点字标记，卡片区为空" % idx)
        return '<p style="margin:0;color:#8a7a5f;font-size:13.5px">本段无重点字标注。</p>'
    html = []
    for n in notes:
        em = '<em>%s</em>' % esc(n["eg"]) if n["eg"] else ""
        html.append(
            '<div class="card"><div class="zi">%s</div><div class="exp">'
            '<p><span class="badge %s">%s</span>%s</p>%s</div></div>'
            % (esc(n["zi"]), n["type"], TYPE_LABEL[n["type"]], esc(n["exp"]), em))
    return "".join(html)


def build(lesson, template, out_path):
    problems, warns = [], []
    paras = lesson.get("paragraphs") or []
    if not paras:
        raise SystemExit("lesson.json 中没有 paragraphs，无法构建。")

    unit = lesson.get("unit", "段")
    nav, sections = [], []
    stats = {"tj": 0, "gj": 0, "hy": 0, "zd": 0}
    total_marks = 0

    for i, p in enumerate(paras, 1):
        pid = p.get("id") or "p%d" % i
        title = p.get("title") or ("第%d%s" % (i, unit))
        num = p.get("num") or ("第" + cn_index(i) + unit)
        nav_label = p.get("nav") or title.split("·")[0].strip()
        orig_raw = (p.get("orig") or "").strip()
        trans = (p.get("trans") or "").strip()

        if not orig_raw:
            problems.append("第%d段：orig（原文）为空" % i)
        if not trans:
            problems.append("第%d段：trans（译文）为空" % i)

        orig_html, notes = render_orig(orig_raw, i, problems, warns)
        # 补充卡片：原文中未高亮、但仍需讲解的字词
        for extra in (p.get("notes") or []):
            zi = (extra.get("zi") or "").strip()
            typ = (extra.get("type") or "zd").lower()
            if not zi:
                problems.append("第%d段：notes 中存在空的 zi" % i)
                continue
            if typ not in TYPE_LABEL:
                problems.append("第%d段：notes 中 %r 的类型 %r 非法" % (i, zi, typ))
                typ = "zd"
            if any(n["zi"] == zi for n in notes):
                warns.append("第%d段：notes 中的 %r 与原文标记重复，已忽略" % (i, zi))
                continue
            notes.append({"zi": zi, "type": typ,
                          "exp": extra.get("exp", ""), "eg": extra.get("eg", "")})
        plain = MARK_RE.sub(lambda m: m.group(1).split("|")[0], orig_raw)
        if trans and len(trans) < len(plain) * 1.05:
            warns.append("第%d段：译文偏短（原文%d字/译文%d字），可能不是完整翻译"
                         % (i, len(plain), len(trans)))
        total_marks += len(MARK_RE.findall(orig_raw))
        for n in notes:
            stats[n["type"]] += 1

        nav.append('<a href="#%s">%s</a>' % (pid, esc(nav_label)))
        sections.append(
            '<section class="para" id="%s">\n'
            '  <h2><span class="num">%s</span>%s</h2>\n'
            '  <div class="block"><h3>原文</h3>\n    <p class="ow">%s</p>\n  </div>\n'
            '  <div class="block"><h3>逐字翻译</h3>\n    <p class="trans">%s</p>\n  </div>\n'
            '  <div class="block"><h3>重点字解释</h3><div class="cards">%s</div></div>\n'
            '</section>'
            % (pid, esc(num), esc(title), orig_html, esc(trans), render_cards(notes, i, warns)))

    html = template
    repl = {
        "{{TITLE}}": lesson.get("title", "文言文逐字翻译课件"),
        "{{SUBTITLE}}": lesson.get("subtitle", "文言文逐字翻译课件"),
        "{{META}}": lesson.get("meta", ""),
        "{{NAV}}": "\n  ".join(nav),
        "{{SECTIONS}}": "\n\n".join(sections),
        "{{FOOTER}}": lesson.get("footer", ""),
    }
    for k, v in repl.items():
        if k not in html:
            problems.append("模板缺少占位符 %s" % k)
        html = html.replace(k, v)

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)

    # ---- 报告 ----
    print("✔ 已生成：%s（%d 段，%d 处标注，%d 张卡片）"
          % (out_path, len(paras), total_marks, sum(stats.values())))
    print("  通假字 %d ｜ 古今异义 %d ｜ 词类活用 %d ｜ 重点字词 %d"
          % (stats["tj"], stats["gj"], stats["hy"], stats["zd"]))
    for w in warns:
        print("  ⚠ " + w)
    if problems:
        print("\n✘ 校验未通过：")
        for p in problems:
            print("  - " + p)
        return False
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("lesson")
    ap.add_argument("-o", "--output", required=True)
    ap.add_argument("--template", default=os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "..", "assets", "template.html"))
    ap.add_argument("--strict", action="store_true", help="有警告即视为失败")
    args = ap.parse_args()

    with open(args.lesson, encoding="utf-8") as f:
        lesson = json.load(f)
    with open(args.template, encoding="utf-8") as f:
        template = f.read()

    ok = build(lesson, template, args.output)
    if not ok:
        sys.exit(1)


if __name__ == "__main__":
    main()
