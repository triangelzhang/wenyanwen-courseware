\---  
name: wenyan-courseware  
version: 1.0.1  
display_name: '文言文逐字翻译课件'  
display_name_en: 'Classical Chinese Translation Courseware'  
description: '把一段或整篇文言文稳定转换成「原文 + 白话译文 + 重点字解释」的交互式 HTML 课件（重点字分通假字、古今异义、词类活用、重点字词四类，可点击查看单字解释）。当用户提供文言文文本或文言文文档（docx/pdf/txt），要求制作逐字翻译、字词讲解、课件、备课讲义、复习资料或网页版讲义时使用。'  
description_zh: '将一段或整篇文言文稳定转换为交互式 HTML 课件：每段包含原文（重点字高亮可点击）、整段白话译文和重点字解释卡片（通假字、古今异义、词类活用、重点字词四类）。适用于文言文教学课件、备课讲义、逐字翻译、字词讲解与复习资料的制作。'  
description_en: 'Stably converts classical Chinese passages into an interactive HTML courseware. Each section contains the original text with clickable highlighted key characters, a fluent modern-Chinese translation, and annotation cards (phonetic loans, semantic shifts, word-class flexibility, and key vocabulary). Ideal for teaching slides, lesson prep handouts, word-by-word translation and review materials.'  
agent_created: true  
\---

# 文言文逐字翻译课件

把文言文转成单文件 HTML 课件：封面 + 段落导航 + 每段「原文（重点字高亮可点击）→ 整段白话译文 → 重点字卡片」三段式版面。排版由模板固定、内容由 JSON 驱动，同一篇课文反复生成结果一致。

## 何时使用

- 用户给出文言文（或文言文 docx/pdf/txt），要求做逐字翻译、字词讲解、课件、讲义、复习材料
- 用户要求把已有文言文课件的版式复用到新篇目
- 不适用：只需白话翻译而不标重点字、只要 Word/PDF 排版、诗词赏析（可复用，但分段与标注密度需自行调低）

## 工作流

按顺序执行；第 5 步校验不通过不得交付。

### 1. 取原文

- 直接给的文本：原样使用。
- docx：先转纯文本，如 `textutil -convert txt -stdout 文件.docx`（macOS），或  
  `python3 -c "import docx;print('\n'.join(p.text for p in docx.Document('f.docx').paragraphs))"`
- pdf：用可用的 PDF 文本提取方式；扫描件先说明无法可靠取字。
- 保留异体字与原有标点，不做「规范化」。用户指定页码范围（如「第 1—5 页」）时，按叙事完整度取整段，并在封面 `meta` 注明范围。

### 2. 分段与小标题

读 `references/annotation-guide.md` 第一节。每段 150—400 字，按叙事单元切分；标题用「主体 · 事件」格式。

### 3. 写译文（「逐字翻译」区块）

读同一文件第二节。整段白话译文，一句对一句，不加评述，不做字下注义。这是最易出错的环节：**译文必须是一段读得通的现代汉语**，不是字词堆叠。

### 4. 标重点字

读同一文件第三节的四类判据与密度要求（每 100 字 3—5 处，每段 6—12 张卡片）。在原文中插入行内标记：

```
[[字词|类型|解释|例句]]
```

类型：`tj` 通假字 / `gj` 古今异义 / `hy` 词类活用 / `zd` 重点字词。标记同时驱动「原文高亮 + 点击气泡 + 卡片」，无需另写卡片内容。若某字只宜讲解、不宜在原文高亮（常见虚词、文化常识），写进该段 `notes` 数组即可。

### 5. 写 lesson.json 并构建

字段与示例见 `references/lesson-schema.md`。JSON 放在源文件同目录，命名 `<篇名>.lesson.json`，然后：

```bash
python3 "<本技能目录>/scripts/build.py" "<篇名>.lesson.json" -o "<篇名>逐字翻译课件.html"
```

构建器输出统计并校验（标记配对、类型合法、译文空缺、译文过短、模板占位符）。**必须 0 错误**；警告逐条处理或确认合理。加 `--strict` 可让警告也判为失败。

### 6. 交付

用 present_files 打开生成的 HTML 预览；回复中说明段数、标注处数、四类分布与文件路径。用户后续要改译文或补段落时，改 JSON 重新构建，不要手改 HTML。

## 质量门

交付前逐条确认：

1. `build.py` 报告 0 错误，无未处理警告。
2. 每段译文连续可读，无文言残留、无漏句。
3. 四类标注均有出现；不出现「满页高亮」或「整段无标注」。
4. 原文异体字、通假字原形未被改写（於 / 後 / 兒）。
5. 卡片例句逐条对应原文片段。

## 文件地图

| 路径                               | 用途                                                                                           |
| -------------------------------- | -------------------------------------------------------------------------------------------- |
| `scripts/build.py`               | JSON → HTML 构建器，含校验与统计（唯一排版入口）                                                               |
| `assets/template.html`           | 版面模板（配色、卡片、气泡 JS、打印样式），占位符 `{{TITLE}} {{SUBTITLE}} {{META}} {{NAV}} {{SECTIONS}} {{FOOTER}}` |
| `references/lesson-schema.md`    | JSON 字段、标记语法、完整示例                                                                            |
| `references/annotation-guide.md` | 分段 / 译文 / 四类标注判据 / 自查清单                                                                      |
| `assets/example-lesson.json`     | 两段可直接构建的最小样例                                                                                 |

## 样式调整

换配色、字体、卡片密度时只改 `assets/template.html` 的 `<style>`；不要改 `build.py` 的拼接逻辑，也不要另手写一套 HTML——手写会破坏结构一致性。模板占位符不可删除或改名，缺失会被构建器报错。

## 注意

- 单段标记内不能出现 `|`。
- 同一字重复高亮会自动去重卡片，不必刻意只标一次。
- 段落数超过 25 时导航过长，按篇拆成多个课件更合适。
